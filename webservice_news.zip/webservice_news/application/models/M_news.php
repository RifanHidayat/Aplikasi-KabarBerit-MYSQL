<?php
class M_news extends CI_Model{


public function kategori($table,$where){

return $this->db->get_where($table,$where);
}

public function cek($table,$where){
	return $this->db->get_where($table,$where);
}

public function tampilAll($table,$where){

return $this->db->get_where($table,$where);
}
public function update($where,$data,$table){
	$this->db->where($where);
	$this->db->update($table,$data);
}
public function hapus($where,$data,$table){
	$this->db->where($where);
	$this->db->delete($table,$data);

}


}