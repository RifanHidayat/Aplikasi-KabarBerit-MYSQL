<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RestFullAPi extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('M_news');
	}


	public function login(){
		$username=$this->input->post('email');
		$password=$this->input->post('pass');
		$user=$this->db->get_where('tb_users',['email'=>$username])->row_array();
		// die;
		if ($user){
			if ($password==$user['pass']){
				$result['value']=1;
				$result['status']="true";
				$result['message']="Berhasil melakukan Login";
				$result['detail']=$user;
				
				header('Content-Type: application/json');
       		
			}else{
				$result['value']=0;
				$result['status']="false";
				$result['message']="Password yang dimasukkan salah";
				header('Content-Type: application/json');
        				
			}

		}else{		
				$result['value']=0;
				$result['statu']="false";
				$result['message']="Email yang dimasukan tidak tersedia";
			
				header('Content-Type: application/json');

		}
		 echo json_encode($result);
	} 

	public function register(){
	
		$email=$this->input->post('email');
		$nama=$this->input->post('nama');
		$telp=$this->input->post('telp');
		$password=$this->input->post('password');
	
		$where_email=array('email'=>$email);
	
		$cekemail=$this->M_news->cek('tb_users',$where_email);
	
		if ($cekemail->num_rows()>=1){
			$result['value']=2;
			$result['status']="false";
			$result['message']="email Sudah digunakan";


		}else{

				$data=[
				'nama'=>$this->input->post('nama'),
				'email'=>$this->input->post('email'),
				'phone'=>$this->input->post('telp'),		
				'pass'=> $this->input->post('pass')
			];
			$daftar=$this->db->insert('tb_users',$data);
			if ($daftar){
			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil melakukan register";
			}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="Gagal melakukan register";
			}
		}

			echo json_encode($result);
			header('Content-Type: application/json');
	
	} 

	public function tambah_berita(){

		$judul=$this->input->post('judul');
		$kategori=$this->input->post('kategori');
		$isi=$this->input->post('isi');
		$photo=$this->input->post('photo');
		$id_user=$this->input->post('id_user');
		$filename=$this->input->post('filename');
		$path ="assets/$judul.jpeg";
		$finalPath = $filename.$path;
		

    
     $img = base64_decode($photo);
    // $image = $name;
    file_put_contents($path, $img);
	
	

				$data=[
				'judul'=>$judul,
				'kategori'=>$kategori,
				'isi'=>$isi,		
				'id_user'=> $id_user,
				'photo_url'=> $finalPath
			];


			$daftar=$this->db->insert('tb_news',$data);
			if ($daftar){
			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil Menambahkan data berita";
			}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="Gagal menambahkan data berita";
			}
		

		
    
 echo json_encode($result);
		header('Content-Type: application/json');


	}
	public function hapus_berita(){
		$id=$this->input->post('id');
		$this->db->where('id',$id);
		$hapus=$this->db->delete('tb_news');
		if ($hapus){
			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil menghapus berita";
			$result['status']=200;

		}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="tidak  berhasil menghapus berita";
			$result['status']=400;

		}
		echo json_encode($result);
			header('Content-Type: application/json');

	}

	public function tampil_berita_kategori(){
		$where=[
				"kategori"=>$this->input->post('kategori')
		];
		$data=$this->db->get_where('tb_news',$where)->result();
		$result['berita']=$data;
		echo json_encode($result);


	}

		public function tampil__berita_user(){
		$where=[
				"id_user"=>$this->input->post('id')
		];
		$data=$this->M_news->tampilAll('tb_news',$where)->result();
		$result['berita']=$data;
		echo json_encode($result);


	}
		public function tampil__all_berita(){
		$where=[
				"id_user"=>$this->input->post('id')
		];

		$data=$this->db->get("tb_news")->result();
		$result['berita']=$data;
		echo json_encode($result);


	}
	public function update_berita(){
		
		$judul=$this->input->post('judul');
		$kategori=$this->input->post('kategori');
		$isi=$this->input->post('isi');
		$photo=$this->input->post('photo');
		$id_berita=$this->input->post('id_berita');
		$filename=$this->input->post('filename');
		$path ="assets/$judul.jpeg";
		$finalPath = $filename.$path;
		
    

	   $img = base64_decode($photo);
    // $image = $name;
    	file_put_contents($path, $img);
   
	

				$data=[
				'judul'=>$judul,
				'kategori'=>$kategori,
				'isi'=>$isi,		
				'photo_url'=> $finalPath
			];
			$where=[
				'id'=>$id_berita

			];

 			
 			$this->db->where($where);


			$update=$this->db->update('tb_news',$data);
	
			

			if ($update){
			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil update data berita";
			}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="Gagal menambahkan data berita";
			}
		

		
    
 			echo json_encode($result);
			header('Content-Type: application/json');


	}
}

